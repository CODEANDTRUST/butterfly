# butterfly-themes
Repository for butterfly themes

## Usage

(sass themes requires the libsass python package to be installed)

Copy an existing theme to the directory butterfly tells you when you type [Alt] + [s] and select it.
You can refresh changes in your style by typing [Alt] + [Shift] + [s]

## Submit your styles

If you are really proud of your theme and want to see it integrated in butterfly just submit a PR.
If you just happen to have create a theme but not proud enough to want it integrated in butterfly submit it anyway, I'll put it in a contrib branch!
